-- FinTel Gold v4 migration
-- Run this once against the existing database/schema before starting redesigned Gold v4.
-- This adds the Silver event/arrival timestamp required for correct as-of matching.
ALTER TABLE fintel_gold.gold_news_sentiment
    ADD COLUMN IF NOT EXISTS event_time TIMESTAMPTZ;

-- Existing rows did not store the Silver event_time. Backfill from published_at
-- only as a best-effort historical fallback; new rows use the actual Silver event_time.
UPDATE fintel_gold.gold_news_sentiment
SET event_time = published_at
WHERE event_time IS NULL;

CREATE INDEX IF NOT EXISTS idx_gold_news_sentiment_symbol_event_time
    ON fintel_gold.gold_news_sentiment (symbol, event_time DESC);
