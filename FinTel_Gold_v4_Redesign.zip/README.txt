FinTel Gold v4 redesign — carry-forward latest-news integration

Files:
- gold_job_v4.py: replaces the current gold/gold_job_v4.py
- gold_storage.py: replaces the current gold/gold_storage.py
- gold_v4_migration.sql: adds event_time to the existing gold_news_sentiment table
- settings_news_no_expiry.txt: one-line config/settings.py adjustment

What changed:
- Removed the strict stock-window/news-window stream-stream INNER JOIN.
- Stock metrics still aggregate independently using the existing window/slide/watermark settings.
- News articles still stream into gold_news_sentiment, now including their Silver event_time.
- For each completed stock window, Gold queries PostgreSQL for the latest article with:
      same symbol AND news.event_time <= stock_window.window_end
- The article is carried forward indefinitely until a newer article is available.
- Each stock window is written to gold_sentiment_price, even when no news exists.
  In that case article_count=0 and sentiment/headline fields are NULL.
- This version associates only the latest article per symbol/window. Retaining and
  associating multiple historical articles is intentionally not implemented.

Important setup order:
1. Stop the existing Gold v4 process with Ctrl+C.
2. Back up the current gold_job_v4.py and gold_storage.py.
3. Run gold_v4_migration.sql once against the same PostgreSQL database and schema
   used by Gold v4. The supplied SQL assumes schema name fintel_gold.
4. Replace gold/gold_job_v4.py with this package's gold_job_v4.py.
5. Replace gold/gold_storage.py with this package's gold_storage.py.
6. In config/settings.py, set NEWS_MAX_AGE_HOURS = None as shown in
   settings_news_no_expiry.txt. Gold v4 itself does not apply an expiry filter.
7. Keep the existing Gold v4 checkpoint folder for stock_metrics and news_articles.
   The redesigned integrated query has a changed query plan: back up and rename
   only data/checkpoints/gold_v4/integrated before the first redesigned run, so
   Spark starts a fresh checkpoint for the changed integrated query. Do not delete
   the stock_metrics or news_articles checkpoints.
8. Start Gold v4 and verify:
   - gold_news_sentiment.event_time is populated for newly processed articles.
   - gold_stock_metrics continues receiving rows.
   - gold_sentiment_price receives rows for stock windows without news too.
   - latest_news_time remains the last known news time across later stock windows.

Timestamp rule:
- event_time is the normalized Silver news arrival/ingestion event timestamp.
- A news item is eligible only for stock windows whose window_end is at or after
  that event_time. It is not attached to earlier stock windows.
- The lookup is as-of event time, not the database insertion time.

Operational note:
The stock integration query and news query are independent. A small scheduling
race is possible if a stock-window batch reaches PostgreSQL before the corresponding
news batch has committed. The 10-minute watermark usually gives the news query
time to persist the article, but this package does not implement a backfill/replay
of already-written stock windows after a late news commit. Validate this behaviour
with your live pipeline before treating the rollout as production-complete.
